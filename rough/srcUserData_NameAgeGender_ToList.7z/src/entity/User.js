export class User {
    name;
    age;
    constructor(){

    }
}